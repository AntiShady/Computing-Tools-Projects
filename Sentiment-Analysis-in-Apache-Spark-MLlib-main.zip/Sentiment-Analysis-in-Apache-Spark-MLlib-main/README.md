# Sentiment-Analysis-in-Apache-Spark-MLlib
Twitter Sentiment Analysis Using Logistic Regression in Apache Spark MLlib 
